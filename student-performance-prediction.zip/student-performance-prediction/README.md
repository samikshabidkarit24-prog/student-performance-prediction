# Student Performance Prediction Using Machine Learning

## Project overview
This beginner-friendly AIML project predicts a student's expected final marks using a Linear Regression model.

## Input features
- `study_hours`: average hours studied per day
- `attendance`: attendance percentage
- `previous_marks`: previous exam marks
- `assignment_score`: assignment score

## Target
- `final_marks`: sample final marks out of 100

## Technologies
- Python
- Pandas
- NumPy
- Scikit-learn

## Files
- `student_performance.py` — trains, evaluates, and runs predictions with the model
- `student_data.csv` — sample dataset created for this educational project
- `requirements.txt` — required Python libraries

## Run locally
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in this folder.
4. Install the libraries:

   ```bash
   python -m pip install -r requirements.txt
   ```

5. Run the project:

   ```bash
   python student_performance.py
   ```

   On some Windows systems, use `py student_performance.py` instead.

6. Enter the new student's study hours, attendance percentage, previous marks, and assignment score when prompted.

## Model evaluation
The program reports MAE, RMSE, and R-squared (R2) on a held-out test set.

## Important note
The included dataset is synthetic sample data created for demonstration, not real student records. Model results are for learning purposes only and should not be used to make real educational decisions.

## Team members
Add each group member's name and roll number here before submission.

## GitHub repository
Add your repository URL here after uploading the project.
