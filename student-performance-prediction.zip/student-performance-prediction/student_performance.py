import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# Load the dataset
data = pd.read_csv("student_data.csv")

# Input features and target
features = ["study_hours", "attendance", "previous_marks", "assignment_score"]
X = data[features]
y = data["final_marks"]

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the Linear Regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Evaluate the model
predictions = model.predict(X_test)
mae = mean_absolute_error(y_test, predictions)
mse = mean_squared_error(y_test, predictions)
rmse = np.sqrt(mse)
r2 = r2_score(y_test, predictions)

print("STUDENT PERFORMANCE PREDICTION")
print("-" * 35)
print(f"Dataset records: {len(data)}")
print(f"Training records: {len(X_train)}")
print(f"Testing records: {len(X_test)}")
print("\nMODEL EVALUATION")
print(f"Mean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"R-squared (R2): {r2:.3f}")

# Predict marks for a new student
print("\nENTER DETAILS FOR A NEW STUDENT")
try:
    hours = float(input("Study hours per day (0.5 to 8): "))
    attend = float(input("Attendance percentage (0 to 100): "))
    previous = float(input("Previous marks (0 to 100): "))
    assignment = float(input("Assignment score (0 to 100): "))

    if not (0 <= hours <= 24 and 0 <= attend <= 100
            and 0 <= previous <= 100 and 0 <= assignment <= 100):
        print("Please enter values within the allowed ranges.")
    else:
        new_student = pd.DataFrame([{
            "study_hours": hours,
            "attendance": attend,
            "previous_marks": previous,
            "assignment_score": assignment
        }])
        predicted_marks = model.predict(new_student[features])[0]
        predicted_marks = max(0, min(100, predicted_marks))
        print(f"\nPredicted final marks: {predicted_marks:.1f} / 100")
        if predicted_marks < 40:
            print("Predicted performance level: Needs Improvement")
        elif predicted_marks < 70:
            print("Predicted performance level: Average")
        else:
            print("Predicted performance level: Good")
except ValueError:
    print("Invalid input. Please enter numeric values.")

print("\nNote: This is an educational demonstration using sample data.")
