import os
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

st.set_page_config(
    page_title="Student Performance AI",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "student_data.csv")

@st.cache_data
def load_data():
    return pd.read_csv(DATA_PATH)

@st.cache_resource
def train_model():
    data = load_data()
    features = ["study_hours", "attendance", "previous_marks", "assignment_score"]
    X = data[features]
    y = data["final_marks"]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = LinearRegression()
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    metrics = {
        "mae": mean_absolute_error(y_test, predictions),
        "rmse": np.sqrt(mean_squared_error(y_test, predictions)),
        "r2": r2_score(y_test, predictions),
    }
    results = X_test.copy()
    results["Actual Marks"] = y_test.values
    results["Predicted Marks"] = np.clip(predictions, 0, 100).round(1)
    return model, metrics, results, features

def performance_label(mark):
    if mark < 40:
        return "Needs Support"
    if mark < 70:
        return "Average"
    return "Good"

def recommendation(mark, study_hours, attendance, previous_marks, assignment_score):
    tips = []
    if study_hours < 2:
        tips.append("Try setting a regular daily study routine and gradually increase focused study time.")
    if attendance < 75:
        tips.append("Improve class attendance where possible and review missed lessons.")
    if previous_marks < 50:
        tips.append("Revise foundational topics and practise short questions regularly.")
    if assignment_score < 60:
        tips.append("Complete assignments on time and ask for feedback on difficult topics.")
    if not tips:
        tips.append("Maintain your current study habits and continue revising regularly.")
    tips.append("Discuss any academic concerns with a teacher or academic adviser.")
    return tips

st.markdown("""
<style>
.main {background-color: #f7f9fc;}
.block-container {padding-top: 1.7rem; padding-bottom: 2rem;}
.hero {
    padding: 1.35rem 1.5rem; border-radius: 18px;
    background: linear-gradient(120deg, #153e75, #2876b8);
    color: white; margin-bottom: 1rem;
}
.hero h1 {color:white; margin-bottom:0.25rem;}
.hero p {color:#e8f2ff; margin-bottom:0;}
.small-note {font-size: 0.85rem; color: #64748b;}
</style>
""", unsafe_allow_html=True)

with st.sidebar:
    st.title("🎓 Student Performance AI")
    st.caption("Academic analytics and prediction")
    page = st.radio(
        "Navigation",
        ["Dashboard", "Predict Performance", "Dataset Explorer", "Model Evaluation"],
        index=0
    )
    st.divider()
    st.caption("AIML Practical No. 10")
    st.caption("Educational demonstration")

data = load_data()
model, metrics, results, features = train_model()

st.markdown("""
<div class="hero">
  <h1>Student Performance Prediction</h1>
  <p>Explore academic data, estimate expected marks, and identify areas where students may need support.</p>
</div>
""", unsafe_allow_html=True)

if page == "Dashboard":
    st.subheader("Overview")
    avg_marks = data["final_marks"].mean()
    avg_attendance = data["attendance"].mean()
    avg_study = data["study_hours"].mean()
    good_count = int((data["final_marks"] >= 70).sum())
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Students in dataset", f"{len(data):,}")
    c2.metric("Average marks", f"{avg_marks:.1f}/100")
    c3.metric("Average attendance", f"{avg_attendance:.1f}%")
    c4.metric("Average study time", f"{avg_study:.1f} hrs/day")

    left, right = st.columns(2)
    with left:
        st.markdown("#### Marks distribution")
        fig = px.histogram(data, x="final_marks", nbins=18,
                           labels={"final_marks":"Final marks"},
                           color_discrete_sequence=["#2876b8"])
        fig.update_layout(margin=dict(l=10,r=10,t=10,b=10), showlegend=False)
        st.plotly_chart(fig, use_container_width=True)
    with right:
        st.markdown("#### Study hours vs final marks")
        fig = px.scatter(data, x="study_hours", y="final_marks",
                         color="attendance",
                         labels={"study_hours":"Study hours/day","final_marks":"Final marks",
                                 "attendance":"Attendance (%)"},
                         color_continuous_scale="Blues")
        fig.update_layout(margin=dict(l=10,r=10,t=10,b=10))
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("#### Academic performance bands")
    bands = pd.cut(data["final_marks"], bins=[-0.1, 39.9, 69.9, 100],
                   labels=["Needs Support", "Average", "Good"])
    counts = bands.value_counts().reindex(["Needs Support", "Average", "Good"]).fillna(0).astype(int)
    band_df = pd.DataFrame({"Performance level": counts.index, "Students": counts.values})
    fig = px.bar(band_df, x="Performance level", y="Students",
                 color="Performance level",
                 color_discrete_sequence=["#e28b75", "#edc56b", "#58a68a"])
    fig.update_layout(showlegend=False, margin=dict(l=10,r=10,t=10,b=10))
    st.plotly_chart(fig, use_container_width=True)
    st.info("This dashboard uses a synthetic sample dataset for demonstration. It is not real student data.")

elif page == "Predict Performance":
    st.subheader("Predict a student's expected marks")
    st.write("Enter academic details below. The trained Linear Regression model estimates marks out of 100.")
    with st.form("prediction_form"):
        col1, col2 = st.columns(2)
        with col1:
            study_hours = st.slider("Study hours per day", 0.0, 12.0, 3.0, 0.5)
            attendance = st.slider("Attendance (%)", 0, 100, 80)
        with col2:
            previous_marks = st.slider("Previous exam marks", 0, 100, 65)
            assignment_score = st.slider("Assignment score", 0, 100, 70)
        submitted = st.form_submit_button("✨ Predict Performance", use_container_width=True)

    if submitted:
        new_student = pd.DataFrame([{
            "study_hours": study_hours,
            "attendance": attendance,
            "previous_marks": previous_marks,
            "assignment_score": assignment_score
        }])
        predicted = float(np.clip(model.predict(new_student[features])[0], 0, 100))
        label = performance_label(predicted)
        st.divider()
        a, b = st.columns([1, 2])
        with a:
            st.metric("Predicted marks", f"{predicted:.1f}/100")
            st.progress(int(round(predicted)))
            st.markdown(f"**Performance band:** {label}")
        with b:
            st.markdown("#### Suggested next steps")
            for tip in recommendation(predicted, study_hours, attendance, previous_marks, assignment_score):
                st.write(f"• {tip}")
        st.caption("Prediction is an estimate from a demonstration dataset, not a guaranteed result or an official academic assessment.")

elif page == "Dataset Explorer":
    st.subheader("Dataset Explorer")
    st.write("Review the sample records used to train and evaluate the model.")
    search_col, filter_col = st.columns([2, 1])
    with search_col:
        min_marks = st.slider("Minimum final marks", 0, 100, 0)
    with filter_col:
        rows_to_show = st.selectbox("Rows to display", [10, 25, 50, 100, "All"], index=1)
    filtered = data[data["final_marks"] >= min_marks]
    shown = filtered if rows_to_show == "All" else filtered.head(int(rows_to_show))
    st.dataframe(shown, use_container_width=True, hide_index=True)
    st.caption(f"Showing {len(shown)} of {len(filtered)} matching records.")
    st.download_button(
        "Download filtered CSV",
        data=filtered.to_csv(index=False).encode("utf-8"),
        file_name="student_performance_data.csv",
        mime="text/csv"
    )
    st.markdown("#### Summary statistics")
    st.dataframe(data.describe().round(2), use_container_width=True)

elif page == "Model Evaluation":
    st.subheader("Model evaluation")
    st.write("The model is tested on a held-out 20% split of the sample dataset.")
    c1, c2, c3 = st.columns(3)
    c1.metric("MAE", f"{metrics['mae']:.2f}", help="Mean Absolute Error; lower is generally better.")
    c2.metric("RMSE", f"{metrics['rmse']:.2f}", help="Root Mean Squared Error; lower is generally better.")
    c3.metric("R² score", f"{metrics['r2']:.3f}", help="R-squared score; interpretation depends on data quality.")
    fig = px.scatter(results, x="Actual Marks", y="Predicted Marks",
                     labels={"Actual Marks":"Actual marks","Predicted Marks":"Predicted marks"},
                     color_discrete_sequence=["#2876b8"])
    fig.add_shape(type="line", x0=0, y0=0, x1=100, y1=100,
                  line=dict(dash="dash", color="gray"))
    fig.update_layout(margin=dict(l=10,r=10,t=10,b=10))
    st.plotly_chart(fig, use_container_width=True)
    st.markdown("#### Test predictions")
    st.dataframe(results[["Actual Marks", "Predicted Marks"]].reset_index(drop=True),
                 use_container_width=True, hide_index=True)
    st.warning("Evaluation metrics describe this synthetic sample dataset only. They should not be presented as validated real-world model performance.")

st.divider()
st.markdown('<p class="small-note">Student Performance Prediction AI • AIML Practical No. 10 • Synthetic educational dataset</p>',
            unsafe_allow_html=True)
