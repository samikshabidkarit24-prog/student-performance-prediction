# Student Performance Prediction AI

A beginner-friendly AIML web application inspired by the structure of modern AI project demos. It predicts estimated marks from academic inputs and provides charts, a dataset explorer, and model evaluation.

## Features
- Dashboard with dataset summary and interactive charts
- Student marks prediction using Linear Regression
- Performance bands and general study suggestions
- Dataset explorer and CSV download
- Model evaluation using MAE, RMSE, and R²
- Streamlit user interface

## Tech stack
Python, Streamlit, Pandas, NumPy, Scikit-learn, Plotly.

## Project structure
```text
student-performance-prediction-ai/
├── app.py
├── requirements.txt
├── README.md
└── data/
    └── student_data.csv
```

## Run on your computer
Python 3.10 or newer is recommended.

1. Extract the ZIP file.
2. Open the project folder in VS Code.
3. Open Terminal in VS Code.
4. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Start the application:
   ```bash
   streamlit run app.py
   ```
6. Streamlit will show a local URL (usually `http://localhost:8501`). Open it in your browser.

On Windows, if `python` is not recognized, try `py -m pip install -r requirements.txt` and `py -m streamlit run app.py`.

## Upload to GitHub
1. Create a public repository named `student-performance-prediction-ai`.
2. Upload `app.py`, `requirements.txt`, `README.md`, and the `data` folder containing `student_data.csv`.
3. Commit the files.
4. Copy the repository URL for your practical submission.

## Dataset note
`data/student_data.csv` contains synthetic sample data generated for demonstration. It is not real student data. Predictions and metrics are illustrative and should not be used for real educational decisions.

## Model
Linear Regression predicts `final_marks` using:
- Study hours per day
- Attendance percentage
- Previous exam marks
- Assignment score

## Team members
Add your group members' names and roll numbers before submission.

## Future improvements
- Use an authentic, appropriately licensed education dataset
- Compare Linear Regression, Random Forest, and Decision Tree models
- Add teacher/admin login and database storage
- Deploy the app online
